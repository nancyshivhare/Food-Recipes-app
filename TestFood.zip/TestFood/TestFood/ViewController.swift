//
//  ViewController.swift
//  TestFood
//
//  Created by DECODER on 03/07/21.
//  Copyright © 2021 com.test. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    var Mymeals =  [[String:Any]]()
        
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var tblRandom: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblRandom.dataSource = self
        tblRandom.delegate = self
        
        
        //api call
        ApiRandome()
        // Do any additional setup after loading the view.
    }
    
    

}

//MARK -  Tabel view delegate's

extension ViewController :UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Mymeals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblRandom.dequeueReusableCell(withIdentifier: "RandomtblCell") as! RandomtblCell
         
        cell.lblTitle.text = self.Mymeals[indexPath.row]["strMeal"] as? String  ?? ""
        let image  = self.Mymeals[indexPath.row]["strMealThumb"] as? String ?? ""
        let url = URL(string: image)
        let data = try? Data(contentsOf: url!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
        cell.lblDescrition.text = self.Mymeals[indexPath.row]["strInstructions"] as? String ?? ""
        cell.imgRecipy.image = UIImage(data: data!)
         
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
            self.ApiSearch(searchtext:textField.text ?? "")
        
        return true
    }
    
    
    

}


//MARk - :Api calls

extension ViewController
{
    func ApiRandome()
    {
    
    ServiceManager.shared.MakeApiCall(ForServiceName: "random.php", withParameters: nil, withAttachments: nil, withAttachmentName: nil, UploadParameter: nil, httpMethod: .get, ShowLoader: true, isTokenNeed: false) { (response) in
            
            print(response!)
            
        
             let meals = response?[0]["meals"]as? [[String:Any]] ?? [[:]]
        if meals.count != 0 {
            
            
               self.Mymeals = meals
            self.tblRandom.reloadData()
            
            }else{
                
               
            }
        }
    }
    
    func ApiSearch(searchtext:String)
     {
    
         
        ServiceManager.shared.MakeApiCall(ForServiceName: "search.php?s=\(searchtext)", withParameters:nil, withAttachments: nil, withAttachmentName: nil, UploadParameter: nil, httpMethod: .get, ShowLoader: true, isTokenNeed: false) { (response) in
             
             print(response!)
             
         
              let meals = response?[0]["meals"]as? [[String:Any]] ?? [[:]]
         if meals.count != 0 {
             
            self.Mymeals.removeAll()
             self.Mymeals = meals
             self.tblRandom.reloadData()
             
             }else{
                 
                
             }
         }
     }
}
