//
//  RandomtblCell.swift
//  TestFood
//
//  Created by DECODER on 03/07/21.
//  Copyright © 2021 com.test. All rights reserved.
//

import UIKit

class RandomtblCell: UITableViewCell {

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgRecipy: UIImageView!
    @IBOutlet weak var lblDescrition: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
