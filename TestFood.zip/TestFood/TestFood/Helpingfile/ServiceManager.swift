//
//  ServiceManager.swift

//

import Foundation
import Alamofire
import KVNProgress


class ServiceManager
{
 
    //Live url
    var url  = "http://www.themealdb.com/api/json/v1/1/"
    var header:HTTPHeaders?
    private let app = UIApplication.shared.delegate as! AppDelegate
    static var Token = ""
    typealias CompletionHandler = ([[String:Any]]?)->Void
    
    static var shared:ServiceManager{
        get{
            struct serviceManager {
                static let manager = ServiceManager()
            }
            return serviceManager.manager
        }
    }
    
    let manager:SessionManager!
    
    init() {
        
        let config = URLSessionConfiguration.default
        config.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        config.urlCache = nil
        
        manager = Alamofire.SessionManager(configuration: config)
    }
    
    
    func MakeApiCall(ForServiceName serviceName:String,withParameters Parameters:[String:Any]?,withAttachments Attachments:[Any]?,withAttachmentName:[String]?,UploadParameter:String?,httpMethod:HTTPMethod,ShowLoader:Bool,isTokenNeed : Bool,completionHandler:@escaping CompletionHandler)
    {
        
       if isTokenNeed{
            
           
                header = ["Authorization":"Bearer " + "","Content-Type" : "application/x-www-form-urlencoded"]
            
        
        }else{
            header = [:]
        }
        
      
        if let attachments = Attachments{
            if (NetworkReachabilityManager()?.isReachable)!{
                if ShowLoader
                {
                    KVNProgress.show()
                }
                manager.upload(multipartFormData: { (multipart) in
                    for Attachment in attachments
                    {
                        let randome = arc4random()
                        let data = (Attachment as! UIImage).jpegData(compressionQuality: 0.8)
                        multipart.append(data!, withName: UploadParameter!, fileName: "randome\(randome).jpg", mimeType: "image/jpg")
                    }
                    if let params = Parameters{
                        print(Parameters!)

                        for (key,value) in params{
                            multipart.append("\(value)".data(using: String.Encoding.utf8)!, withName: "\(key)")
                        }
                    }
                }, to: URL.init(string: "\(url)\(serviceName)")!,headers:["Authorization":"Bearer " + "","Content-Type" : "multipart/form-data"],  encodingCompletion: { (Responce) in
                    
                    print("-------------")
                    
                    print(Responce)
                    
                    print("-------------")
                    
                    switch Responce {
                        
                        
                        
                    case .success(let upload, _, _):
                        upload.responseJSON { Responce in
                            

                            if Responce.error == nil
                            {
                                if ShowLoader{
                                    KVNProgress.dismiss(completion: {
                                        guard let responce = Responce.result.value else{return}
                                        guard let dic = responce as? [String:Any] else{return}
                                        var responceArray:Array = [[String:Any]]()
                                        responceArray.append(dic)
                                        
                                        completionHandler(responceArray)
                                    })
                                }
                                else
                                {
                                    guard let responce = Responce.result.value else{return}
                                    guard let dic = responce as? [String:Any] else{return}
                                    var responceArray:Array = [[String:Any]]()
                                    responceArray.append(dic)
                                    
                                    completionHandler(responceArray)
                                }
                            }
                            else
                            {
                                if ShowLoader{
                                    KVNProgress.dismiss(completion: {
                                        guard let vc = self.app.window?.rootViewController else {return}
                                        //UIAlertController().ServerError(PresentOn: vc)
                                    })
                                }
                                else
                                {
                                    guard let vc = self.app.window?.rootViewController else {return}
                                   // UIAlertController().ServerError(PresentOn: vc)
                                }
                            }
                        }
                    case .failure( let error):
                        print(error)
                        if ShowLoader{
                        
                            KVNProgress.dismiss(completion: {
                                guard let vc = self.app.window?.rootViewController else {return}
                                //UIAlertController().ServerError(PresentOn: vc)
                            })
                        }
                        else
                        {
                            guard let vc = self.app.window?.rootViewController else {return}
                            //UIAlertController().ServerError(PresentOn: vc)
                        }
                    }
                })
            }
            else
            {
                
                guard let vc = app.window?.rootViewController else {return}
               // UIAlertController().NoInternet(PresentOn: vc)
            }
        }
        else
        {
            if (NetworkReachabilityManager()?.isReachable)!{
                if ShowLoader
                {
                    KVNProgress.show()
                }
                manager.request(URL.init(string: "\(url)\(serviceName)")!, method: httpMethod,parameters: Parameters, encoding: JSONEncoding.default,headers: header).validate(statusCode: 200..<600).responseJSON(completionHandler: { (Responce) in
                    
                    if Responce.error == nil
                    {
                            if ShowLoader{
                                KVNProgress.dismiss(completion: {
                                    guard let responce = Responce.result.value else{return}
                                    guard let dic = responce as? [String:Any] else{return}
                                    var responceArray:Array = [[String:Any]]()
                                    responceArray.append(dic)
                                    
                                    completionHandler(responceArray)
                                })
                            }
                            else
                            {
                                guard let responce = Responce.result.value else{return}
                                guard let dic = responce as? [String:Any] else{return}
                                var responceArray:Array = [[String:Any]]()
                                responceArray.append(dic)
                                
                                completionHandler(responceArray)
                            }
                    }
                    else
                    {
                        if ShowLoader{
                            KVNProgress.dismiss(completion: {
                                guard let vc = self.app.window?.rootViewController else {return}
                               // UIAlertController().ServerError(PresentOn: vc)
                            })
                        }
                        else
                        {
                            guard let vc = self.app.window?.rootViewController else {return}
                           // UIAlertController().ServerError(PresentOn: vc)
                        }
                    }
                })
            }
            else
            {
                guard let vc = app.window?.rootViewController else {return}
               // UIAlertController().NoInternet(PresentOn: vc)
            }
        }
    }
}
